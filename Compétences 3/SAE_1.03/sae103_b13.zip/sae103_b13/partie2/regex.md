egrep [^/\]*[/\]$ < src1.c

egrep ^[/??*] < src1.c

egrep -o  '/\*\*.*\*/' < src1.c
